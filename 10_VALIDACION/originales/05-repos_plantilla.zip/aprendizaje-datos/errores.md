# Cuaderno de errores

Formato: `fecha · ejercicio · error · regla para la próxima`

- 2026-10-12 · S3 · escribí `ruta = R03` sin comillas · los textos van entre comillas simples
