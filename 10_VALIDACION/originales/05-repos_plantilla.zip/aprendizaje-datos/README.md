# Aprendizaje de datos · diario público

Repositorio donde dejo todo lo que practico: estadística, Python/Pandas, notas y mi cuaderno de errores. Reto: 12 de octubre al 15 de noviembre de 2026.

## Estructura
- `errores.md` · cuaderno de errores (fecha · ejercicio · error · regla para la próxima)
- `estadistica/` · notebooks de estadística descriptiva, percentiles, normal, muestreo e inferencia
- `python/` · notebooks de Pandas, recencia, ABC
- `notas/` · apuntes y resúmenes de teoría con su fuente

## Regla
Un commit por día, aunque sea pequeño.
