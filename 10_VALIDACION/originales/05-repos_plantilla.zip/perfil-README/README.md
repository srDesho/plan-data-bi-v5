# Hola, soy Ludwing 👋

Técnico Superior en Sistemas Informáticos en Santa Cruz de la Sierra, Bolivia. Me enfoco en análisis de datos: SQL, Power BI, Python (Pandas) y ETL. Busco mi primer puesto como **Analista BI / Analista de Datos** y, más adelante, crecer hacia Ingeniería de Datos.

## Proyectos
| Proyecto | Qué hace |
|---|---|
| [sql-distribuidora](https://github.com/TU_USUARIO/sql-distribuidora) | Análisis SQL de una distribuidora (drop size, ABC, clientes inactivos) |
| [etl-distribuidora](https://github.com/TU_USUARIO/etl-distribuidora) | ETL de un archivo sucio con capas bronze, silver y gold |
| [dashboard-powerbi-distribuidora](https://github.com/TU_USUARIO/dashboard-powerbi-distribuidora) | Tablero de Power BI con modelo en estrella y DAX |

## Herramientas
SQL · Power BI · DAX · Excel · Python · Pandas · SQLite · Git

## Contacto
LinkedIn: [tu enlace] · Correo: [tu correo]

*Los datos de los proyectos son inventados o públicos. No incluyen información de ninguna empresa.*

> Instrucciones: crea un repositorio público con el MISMO nombre que tu usuario de GitHub y pega este archivo como su README.md. Cambia TU_USUARIO.
