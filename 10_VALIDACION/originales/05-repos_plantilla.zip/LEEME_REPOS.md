# Plantillas de repositorios de GitHub

Cada carpeta de aquí es un repositorio. Crea el repo en GitHub con el mismo nombre, copia el contenido y haz tu primer commit.

| Carpeta | Cuándo lo creas | Qué lleva |
|---|---|---|
| `aprendizaje-datos` | Lun 12 oct | `errores.md`, notebooks de estadística y Pandas, notas |
| `sql-distribuidora` | Lun 12 oct (público el sáb 17 oct) | Plantillas de ejercicios `.sql` con enunciados y cifras de control (sin soluciones) |
| `etl-distribuidora` | Lun 26 oct (público el sáb 31 oct) | Esqueleto del ETL y README |
| `dashboard-powerbi-distribuidora` | Lun 2 nov (público el sáb 7 nov) | Modelo, `.pbix`, capturas, PDF, README |
| `olist-capstone` | Opcional, después del 8 nov (próximos 30 días) | SQL, notebooks, resumen ejecutivo |
| `perfil-README` | Sáb 7 nov | README de tu perfil de GitHub (el repo se llama igual que tu usuario) |

## Cómo se usan los archivos .sql de `sql-distribuidora`
Cada archivo trae los enunciados y, cuando existe, la **cifra de control**. Escribe tu consulta debajo de `-- TU CONSULTA:`. Las soluciones están en `Soluciones_SQL_v3.sql`: mírala solo después de intentar y comparar con el control.

## Carpeta de datos
Copia la carpeta `datos_practica/` (del archivo `datos_practica_v3.zip`) dentro de cada repo que la use. Para el ETL, el archivo sucio va en `datos_practica/etl/`.

## Mensajes de commit
Cortos y concretos, en pasado o infinitivo: `dia 5: JOIN y anti-join`, `agrega validaciones del ETL`, `corrige cuadre de ventas`. Un commit por día mínimo.

## Antes de hacer público un repo
- [ ] README completo (problema, datos, herramientas, cómo reproducir, resultados, aprendizaje)
- [ ] Sin contraseñas, tokens ni rutas de tu computadora
- [ ] Sin datos reales de ninguna empresa ni de Cruzimex
- [ ] Datos inventados indicados como tales
- [ ] Sin archivos pesados (más de 50 MB)
- [ ] Temas (topics) agregados: `sql`, `power-bi`, `etl`, `python`, `data-analysis`
- [ ] Repo fijado (pinned) en tu perfil
