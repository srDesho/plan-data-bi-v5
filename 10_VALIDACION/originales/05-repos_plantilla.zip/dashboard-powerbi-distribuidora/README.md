# Tablero de Power BI · Distribuidora (datos inventados)

Tablero de 2 páginas con modelo en estrella y medidas DAX.

## Qué problema de negocio responde
Cómo evolucionan las ventas, qué rutas anulan más, cuánto vale cada entrega y qué clientes concentran las ventas.

## Modelo en estrella
- Hechos: `fact_ventas` (16 178 líneas de pedido)
- Dimensiones: `dim_cliente` (120), `dim_producto` (40), `dim_vendedor` (6), `dim_fecha` (183 días)

[Pega aquí la captura de la vista de modelo]

## Medidas DAX
```
Ventas = CALCULATE(SUMX(fact_ventas, fact_ventas[cantidad] * fact_ventas[precio_unitario]), fact_ventas[estado] = "entregado")
Pedidos entregados = CALCULATE(DISTINCTCOUNT(fact_ventas[pedido_id]), fact_ventas[estado] = "entregado")
Drop size = DIVIDE([Ventas], [Pedidos entregados])
% Anulados = DIVIDE(CALCULATE(DISTINCTCOUNT(fact_ventas[pedido_id]), fact_ventas[estado] = "anulado"), DISTINCTCOUNT(fact_ventas[pedido_id]))
```
(Ajusta los nombres de tabla y columna a tu modelo.)

## Cuadre de cuatro herramientas
| Herramienta | Ventas entregadas |
|---|---|
| SQL | 1 468 924,50 |
| Pandas | |
| Excel | |
| Power BI | |

## Hallazgos (5, con números)
1.
2.
3.
4.
5.

## Capturas y video
`img/` · PDF del tablero · [enlace al video]

## Qué aprendí / qué mejoraría
-

## Herramientas
Power BI Desktop · DAX · Power Query · SQLite/Pandas (preparación) · Excel (cuadre)
