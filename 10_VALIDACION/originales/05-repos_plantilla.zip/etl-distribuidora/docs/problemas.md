# Problemas encontrados en el archivo sucio

| # | Columna | Problema | Cómo lo resolví |
|---|---|---|---|
| 1 | | | |
