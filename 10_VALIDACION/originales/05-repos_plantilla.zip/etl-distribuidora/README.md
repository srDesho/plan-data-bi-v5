# ETL · Distribuidora (datos inventados)

Toma una exportación sucia de un ERP inventado (16 378 filas) y la deja limpia en tres capas (bronze, silver, gold), con validaciones que cuadran con el total calculado por SQL.

## Qué problema de negocio responde
Los datos de ventas llegan con duplicados, formatos mezclados y campos vacíos. Este ETL los deja listos para analizar y para Power BI.

## Datos
Archivo inventado `datos_practica/etl/ventas_erp_raw.csv`. Problemas incluidos: 200 duplicados, 3 formatos de fecha, 6 variantes de estado, 574 nombres para 120 clientes, 301 vendedores vacíos, precios como "Bs 11,50".

## Arquitectura
```
archivo sucio -> BRONZE (crudo) -> SILVER (limpio) -> GOLD (cliente x mes) -> Power BI
```
[Pega aquí tu diagrama]

## Cómo ejecutarlo
```bash
pip install -r requirements.txt
python src/etl.py
```
Crea `etl_salida.db` con `bronze_ventas_raw`, `silver_ventas` y `gold_ventas_cliente_mes`.

## Validaciones y cuadre
| Control | Esperado |
|---|---|
| Filas silver | 16 178 |
| Pedidos únicos | 3 600 |
| Clientes | 120 |
| Ventas entregadas | 1 468 924,50 Bs (igual que la consulta en SQL) |
| Filas gold | 581 |

## Qué aprendí
- [3 lecciones]

## Qué mejoraría
- [Por ejemplo: pruebas automáticas, parámetros por línea de comandos]

## Herramientas
Python · Pandas · SQLite · logging
