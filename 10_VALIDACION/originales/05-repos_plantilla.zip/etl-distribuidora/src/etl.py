"""ETL de la distribuidora: esqueleto. Completa cada funcion tu mismo."""
import logging
import sqlite3
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent.parent
RAW = BASE / "datos_practica" / "etl" / "ventas_erp_raw.csv"
VEND = BASE / "datos_practica" / "etl" / "vendedores_por_ruta.csv"
DB_OUT = BASE / "etl_salida.db"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("etl")


def extraer():
    """Lee el archivo sucio (sep=';', dtype=str) y la tabla de vendedores por ruta."""
    raise NotImplementedError


def transformar(raw, vend):
    """Limpia: textos, estado, ruta, clientes, duplicados, fechas, precios, cantidades, vendedores, monto."""
    raise NotImplementedError


def validar(df):
    """assert para cada regla: nulos, estados, 120 clientes, 3600 pedidos, 16178 filas, total 1468924.50."""
    raise NotImplementedError


def cargar(raw, silver):
    """Escribe bronze, silver y gold en etl_salida.db."""
    raise NotImplementedError


def main():
    raw, vend = extraer()
    silver = transformar(raw, vend)
    validar(silver)
    cargar(raw, silver)


if __name__ == "__main__":
    main()
