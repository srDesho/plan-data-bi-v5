# SQL · Distribuidora (datos inventados)

Ejercicios de SQL sobre una distribuidora ficticia de Santa Cruz de la Sierra. **Todos los datos son inventados.**

## Qué problema de negocio responde
Cuánto se vende, a quién, por qué ruta, cuál es el drop size (valor de cada entrega), qué clientes dejaron de comprar y cómo se concentran las ventas (clasificación ABC).

## Datos
- 120 clientes · 6 rutas · 6 vendedores · 40 productos · 3 600 pedidos (abril a septiembre de 2026)
- Base SQLite: `datos_practica/distribuidora.db` (más los mismos datos en CSV)

## Contenido
| Carpeta / archivo | Tema |
|---|---|
| `sql/01_select.sql` | SELECT, WHERE, ORDER BY, LIKE, IN, NULL |
| `sql/02_agregados.sql` | COUNT, SUM, AVG, GROUP BY, HAVING |
| `sql/03_joins.sql` | INNER JOIN, LEFT JOIN, anti-join |
| `sql/04_drop_size.sql` | Drop size, CASE, subconsultas, CTE |
| `sql/05_ultima_compra.sql` | Última compra y recencia |
| `sql/06_ventanas_abc.sql` | Funciones de ventana y clasificación ABC |
| `sql/07_limpieza.sql` | Limpieza de datos |
| `examenes/` | Exámenes cronometrados |

## Cómo reproducirlo
1. Abre `datos_practica/distribuidora.db` con DBeaver (nueva conexión, SQLite) o con Python:
   ```python
   import sqlite3, pandas as pd
   con = sqlite3.connect("datos_practica/distribuidora.db")
   pd.read_sql("SELECT COUNT(*) FROM clientes", con)
   ```
2. Ejecuta los archivos de `sql/` en orden.

## Resultados principales
- Ventas entregadas: **1 468 924,50 Bs** (3 442 pedidos) · drop size promedio **426,76 Bs**
- Clasificación ABC: A = 41 clientes (80,5%), B = 37 (14,6%), C = 42 (4,9%)
- [Escribe aquí tus 3 hallazgos, con números]

## Qué aprendí
- [Tus 3 lecciones, por ejemplo: la condición de un LEFT JOIN va en el ON]

## Qué mejoraría
- [Por ejemplo: agregar pruebas de cifras de control automáticas]

## Herramientas
SQLite · DBeaver · SQL
