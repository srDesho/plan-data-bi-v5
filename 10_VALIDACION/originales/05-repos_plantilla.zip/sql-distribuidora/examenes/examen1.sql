-- EXAMEN 1 · semana 1 (90 minutos, sin soluciones)
-- Base: datos_practica/distribuidora.db (SQLite)
-- Regla: intenta 10 minutos tu solo, compara con el control y anota el error en errores.md


-- [E1] Tipos de cliente con más de 10 clientes
-- Control: Tienda de barrio 55 | Minimarket 27 | Restaurante 23 | Kiosco 12
-- TU CONSULTA:



-- [E2] Las 3 bebidas más caras
-- Control: Energizante 250ml 12.0 | Gaseosa cola 2L 11.5 | Gaseosa naranja 2L 10.5
-- TU CONSULTA:



-- [E3] Pedidos anulados por mes
-- Control: abril 24 | mayo 28
-- TU CONSULTA:



-- [E4] Ventas (Bs) por ruta, solo entregados
-- Control: R01 211141.50 | R02 396680.50 (las 6 rutas suman 1468924.50)
-- TU CONSULTA:



-- [E5] Clientes de la zona Centro con su cantidad de pedidos entregados (incluye los que tienen 0)
-- Control: 17 clientes
-- TU CONSULTA:



-- [E6] Unidades vendidas por tipo de cliente y categoría de producto (entregados)
-- Control: 25 filas
-- TU CONSULTA:



-- [E7] Pedidos de septiembre con más de 10 ítems
-- Control: 3 pedidos (el primero: 3007 con 11 items)
-- TU CONSULTA:



-- [E8] Clientes que nunca tuvieron un pedido anulado
-- Control: 51 clientes
-- TU CONSULTA:

