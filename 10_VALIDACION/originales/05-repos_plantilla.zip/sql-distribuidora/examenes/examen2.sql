-- EXAMEN 2 · semana 2 (2 horas, sin soluciones)
-- Base: datos_practica/distribuidora.db (SQLite)
-- Regla: intenta 10 minutos tu solo, compara con el control y anota el error en errores.md


-- [X1] Ventas (Bs) por mes, solo entregados
-- Control: abr 246380.0 | may 246941.5 | jun 244671.0 | jul 230982.0 | ago 199028.0 | sep 300922.0
-- TU CONSULTA:



-- [X2] Drop size promedio por mes
-- TU CONSULTA:



-- [X3] Top 10 clientes por ventas
-- TU CONSULTA:



-- [X4] Ventas por categoría y % del total
-- TU CONSULTA:



-- [X5] Porcentaje de pedidos anulados por ruta
-- Control: R01 2.5 | R02 4.2 | R03 3.7 | R04 4.1 | R05 5.2 | R06 6.6
-- TU CONSULTA:



-- [X6] Pedido con mayor drop size (con cliente y fecha)
-- Control: pedido 814 (2560.50)
-- TU CONSULTA:



-- [X7] Ranking de vendedores por ventas
-- TU CONSULTA:



-- [X8] Clientes con zona nula y cuánto compraron (revela datos que hay que corregir en origen)
-- Control: 6 clientes
-- TU CONSULTA:

