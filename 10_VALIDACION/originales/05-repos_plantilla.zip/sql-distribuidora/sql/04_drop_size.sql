-- 04 · Drop size, CASE, subconsultas, CTE
-- Base: datos_practica/distribuidora.db (SQLite)
-- Regla: intenta 10 minutos tu solo, compara con el control y anota el error en errores.md


-- [K1] Drop size (Bs) y unidades de cada pedido entregado
-- TU CONSULTA:



-- [K2a] Drop size promedio general
-- Control: 426.76
-- TU CONSULTA:



-- [K2b] Drop size promedio por ruta
-- Control: R01 365.93 | R02 461.26 | R03 404.46 | R04 413.36 | R05 508.24 | R06 351.07
-- TU CONSULTA:



-- [K3] Pedidos con drop size mayor al promedio general (subconsulta)
-- TU CONSULTA:



-- [K4] Clasificar pedidos en Pequeño (<200), Mediano (200 a 600) y Grande (>600) y contarlos
-- Control: 781 pequenos | 1911 medianos | 750 grandes
-- TU CONSULTA:



-- [K5] Top 10 pedidos por drop size, con cliente y vendedor
-- Control: pedido 814 con 2560.50
-- TU CONSULTA:



-- [K6] Con CTE: drop size promedio por cliente y los 5 mayores
-- TU CONSULTA:

