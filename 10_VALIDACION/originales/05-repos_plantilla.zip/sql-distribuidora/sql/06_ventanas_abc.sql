-- 06 · Funciones de ventana y clasificacion ABC
-- Base: datos_practica/distribuidora.db (SQLite)
-- Regla: intenta 10 minutos tu solo, compara con el control y anota el error en errores.md


-- [V3] Ventas por cliente, participación % y acumulado %
-- TU CONSULTA:



-- [V4] Clasificación ABC: A = hasta 80% de las ventas, B = hasta 95%, C = el resto
-- Control: A 41 (80.5%) | B 37 (14.6%) | C 42 (4.9%)
-- TU CONSULTA:



-- [V5] Ranking de clientes por ventas dentro de cada ruta (los 3 mejores por ruta)
-- TU CONSULTA:

