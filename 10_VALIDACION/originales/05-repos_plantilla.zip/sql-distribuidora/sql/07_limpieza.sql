-- 07 · Limpieza de datos (TRIM, UPPER, COALESCE)
-- Base: datos_practica/distribuidora.db (SQLite)
-- Regla: intenta 10 minutos tu solo, compara con el control y anota el error en errores.md


-- [CL1] Detectar nombres de negocio con espacios al inicio o al final (control: 8)
-- Control: 8
-- TU CONSULTA:



-- [CL2] Nombres normalizados: sin espacios sobrantes y en mayúsculas
-- TU CONSULTA:



-- [CL3] Clientes por zona, mostrando 'Sin zona' cuando es NULL (control: 'Sin zona' = 6)
-- Control: 'Sin zona' = 6
-- TU CONSULTA:



-- [CL4] Vista TEMPORAL con clientes limpios (no modifica el archivo .db) y consulta de prueba
-- TU CONSULTA:

