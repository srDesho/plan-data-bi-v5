-- 02 · Agregaciones, GROUP BY, HAVING
-- Base: datos_practica/distribuidora.db (SQLite)
-- Regla: intenta 10 minutos tu solo, compara con el control y anota el error en errores.md


-- [G1] Pedidos entregados y anulados
-- Control: 3442 entregados y 158 anulados
-- TU CONSULTA:



-- [G2] Unidades vendidas en total
-- Control: 164517 unidades
-- TU CONSULTA:



-- [G3] Valor total de los ítems (incluye pedidos anulados: mañana lo corriges con un JOIN)
-- Control: 1534625 (incluye anulados)
-- TU CONSULTA:



-- [G4] Precio promedio, mínimo y máximo por categoría
-- TU CONSULTA:



-- [G5] Clientes por ruta, de mayor a menor
-- Control: R01 = 26 clientes
-- TU CONSULTA:



-- [G6] Rutas con más de 20 clientes (HAVING filtra grupos; WHERE filtra filas)
-- Control: 3 rutas
-- TU CONSULTA:



-- [G7] Clientes por tipo y zona (los NULL aparecen como un grupo propio)
-- TU CONSULTA:



-- [G8] Pedidos por mes
-- Control: 6 meses
-- TU CONSULTA:

