-- 03 · JOIN, LEFT JOIN y anti-join
-- Base: datos_practica/distribuidora.db (SQLite)
-- Regla: intenta 10 minutos tu solo, compara con el control y anota el error en errores.md


-- [J1] Pedidos con el nombre del cliente
-- TU CONSULTA:



-- [J2] Ventas totales (Bs) de pedidos entregados
-- Control: 1468924.50
-- TU CONSULTA:



-- [J3] Ventas por categoría de producto
-- Control: Lacteos primero con 406249
-- TU CONSULTA:



-- [J4] Ventas por vendedor
-- Control: la suma de los 6 vendedores = 1468924.50
-- TU CONSULTA:



-- [J5] Clientes SIN pedidos entregados en septiembre
-- Control: 19 clientes
-- TU CONSULTA:



-- [J6] Top 5 productos por unidades entregadas
-- TU CONSULTA:

