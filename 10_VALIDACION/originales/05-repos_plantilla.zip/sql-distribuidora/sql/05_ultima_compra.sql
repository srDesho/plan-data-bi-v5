-- 05 · Ultima compra y recencia
-- Base: datos_practica/distribuidora.db (SQLite)
-- Regla: intenta 10 minutos tu solo, compara con el control y anota el error en errores.md


-- [V1] Última compra (entregada) por cliente
-- TU CONSULTA:



-- [V2] Clientes que no compran hace más de 60 días (fecha de corte 2026-09-30)
-- Control: 11 clientes
-- TU CONSULTA:

