-- 01 · SELECT, WHERE, ORDER BY, LIKE, IN, NULL
-- Base: datos_practica/distribuidora.db (SQLite)
-- Regla: intenta 10 minutos tu solo, compara con el control y anota el error en errores.md


-- [S1] Primeras 10 filas de clientes
-- TU CONSULTA:



-- [S2] Tipos de negocio distintos
-- TU CONSULTA:



-- [S3] Clientes de la ruta R03
-- TU CONSULTA:



-- [S4] Bebidas con precio > 10, de mayor a menor precio
-- TU CONSULTA:



-- [S5] Kioscos o farmacias
-- TU CONSULTA:



-- [S6] Nombre que contiene "sol"
-- TU CONSULTA:



-- [S7] Clientes sin zona
-- TU CONSULTA:



-- [S8] Pedidos del 1 al 15 de septiembre
-- TU CONSULTA:



-- [S9] Precio entre 5 y 10 en Snacks o Lácteos
-- TU CONSULTA:



-- [S10] Cuántos clientes hay
-- Control: 120
-- TU CONSULTA:

