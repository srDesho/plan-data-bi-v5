# Olist · Retrasos de entrega y reseñas (datos reales públicos)

Caso de estudio con el dataset público "Brazilian E-Commerce Public Dataset by Olist" (Kaggle).

## Preguntas de negocio
1. ¿Cuántos días tarda una entrega y cómo varía por estado?
2. ¿Qué porcentaje llega tarde?
3. ¿Los retrasos bajan la puntuación de las reseñas?
4. ¿Qué categorías generan más ingresos?
5. ¿Cuánto de las ventas se concentra en pocos vendedores?

## Datos
Descárgalos de Kaggle (cuenta gratuita) y colócalos en `data/` (no se suben al repositorio).

## Método
SQL (SQLite) y Pandas. Cada resultado se calcula por dos caminos y deben coincidir.

## Resumen ejecutivo
- [5 viñetas: hallazgo, número, recomendación]

## Resultados
[Capturas de gráficos y tablas]

## Límites de lo que se puede concluir
- [Correlación no es causa; datos de un periodo; etc.]

## Cómo reproducirlo
```bash
pip install -r requirements.txt
python src/cargar_olist.py
```

## Herramientas
Python · Pandas · SQLite · SQL · Matplotlib/Seaborn · scipy
