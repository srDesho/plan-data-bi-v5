"""Carga los CSV de Olist en SQLite (esqueleto)."""
import sqlite3
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / "data"
DB = BASE / "olist.db"


def main():
    with sqlite3.connect(DB) as con:
        for csv in sorted(DATA.glob("*.csv")):
            df = pd.read_csv(csv)
            df.to_sql(csv.stem, con, if_exists="replace", index=False)
            print(csv.name, df.shape)


if __name__ == "__main__":
    main()
